package doc.student.fitnesstrainerapp.Activities;

public class PersonDetailsActivity {
}
